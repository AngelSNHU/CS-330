///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";

// shared textures and materials tags
	constexpr const char* TEXTURE_FABRIC = "fabric";
	constexpr const char* TEXTURE_METAL = "metal";
	constexpr const char* TEXTURE_CHAIN_END = "chainEnd";
	constexpr const char* TEXTURE_WOOD = "wood";
	constexpr const char* MATERIAL_PLASTIC = "plastic";
	constexpr const char* TEXTURE_NOVEL = "novel";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
	//start with no loaded textures
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	// Release textures 
	DestroyGLTextures();

	delete m_basicMeshes;
	m_basicMeshes = NULL;
	m_pShaderManager = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		STBI_rgb);

	// if the image was successfully read from the image file
	if (image)
	{
		//Match channel count to RGB data
		colorChannels = 3;

		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set mipmap for smoother textures when far away
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		//for packed RGB rows
		glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		//restore default pixel unpack alignment
		glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glDeleteTextures(1, &m_textureIDs[i].ID);
		m_textureIDs[i].ID = 0;
		m_textureIDs[i].tag.clear();
	}
	//reset count once textures release
	m_loadedTextures = 0;
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}
//return requested material if found
	return(bFound);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		int textureSlot = FindTextureSlot(textureTag);

		// neutral color if texture is missing
		if (textureSlot == -1)
		{
			SetShaderColor(0.5f, 0.5f, 0.5f, 1.0f);
			return;
		}

		// apply texture when slot is valid
		m_pShaderManager->setIntValue(g_UseTextureName, true);
		m_pShaderManager->setSampler2DValue(
			g_TextureValueName, textureSlot);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


/***********************************************************
 *  DefineObjectMaterials()
 *
 *  Set tabletop and lamps responses to light
 ***********************************************************/

void SceneManager::DefineObjectMaterials()
{ 
	m_objectMaterials.clear();

	OBJECT_MATERIAL material;

	//tabletop mild highlight
	material.tag = TEXTURE_WOOD;
	material.diffuseColor = glm::vec3(1.0f);
	material.specularColor = glm::vec3(0.7f);
	material.shininess = 64.0f;
	m_objectMaterials.push_back(material);

	// metal lamp parts with strongest reflection
	material.tag = TEXTURE_METAL;
	material.diffuseColor = glm::vec3(1.0f);
	material.specularColor = glm::vec3(0.8f);
	material.shininess = 64.0f;
	m_objectMaterials.push_back(material);

	// fabric shade with little reflection
	material.tag = TEXTURE_FABRIC;
	material.diffuseColor = glm::vec3(1.0f);
	material.specularColor = glm::vec3(0.05f);
	material.shininess = 8.0f;
	m_objectMaterials.push_back(material);

	// pull chain end with a small highlight
	material.tag = TEXTURE_CHAIN_END;
	material.diffuseColor = glm::vec3(1.0f);
	material.specularColor = glm::vec3(0.2f);
	material.shininess = 16.0f;
	m_objectMaterials.push_back(material);

	// plastic cup with a weaker highlight
	material.tag = MATERIAL_PLASTIC;
	material.diffuseColor = glm::vec3(1.0f);
	material.specularColor = glm::vec3(0.25f);
	material.shininess = 32.0f;
	m_objectMaterials.push_back(material);
}

/***********************************************************
 * SetupSceneLights()
 * Lighting for room
 ***********************************************************/
void SceneManager::SetupSceneLights()
	{
		constexpr int MAX_POINT_LIGHTS = 5;

		// Kept room light settings together (easier for correcting)
		const glm::vec3 ROOM_DIRECTION(-0.5f, -1.0f, -0.3f);
		const glm::vec3 ROOM_AMBIENT(0.55f);
		const glm::vec3 ROOM_DIFFUSE(0.45f);
		const glm::vec3 ROOM_SPECULAR(0.15f);

		// Store each point light's settings
		struct PointLightSettings
		{
			glm::vec3 position;
			glm::vec3 ambient;
			glm::vec3 diffuse;
			glm::vec3 specular;
		};

		// Warm lamp light
		const PointLightSettings POINT_LIGHT_SETTINGS[] =
		{
			{
			glm::vec3(1.0f, 8.0f, 8.0f),    // Position
			glm::vec3(0.08f, 0.072f, 0.064f), // Ambient
			glm::vec3(0.90f, 0.81f, 0.72f),   // Diffuse
			glm::vec3(0.35f, 0.315f, 0.28f)   // Specular
			}
		};

		const int ACTIVE_POINT_LIGHTS =
			static_cast<int>(
				sizeof(POINT_LIGHT_SETTINGS) /
				sizeof(POINT_LIGHT_SETTINGS[0]));

		m_pShaderManager->setIntValue(g_UseLightingName, true);

		// Create directional light 
		m_pShaderManager->setIntValue("directionalLight.bActive", true);
		m_pShaderManager->setVec3Value(
			"directionalLight.direction", ROOM_DIRECTION);
		m_pShaderManager->setVec3Value(
			"directionalLight.ambient", ROOM_AMBIENT);
		m_pShaderManager->setVec3Value(
			"directionalLight.diffuse", ROOM_DIFFUSE);
		m_pShaderManager->setVec3Value(
			"directionalLight.specular", ROOM_SPECULAR);

		// Set point lights
		for (int i = 0; i < MAX_POINT_LIGHTS; i++)
		{
			const std::string prefix =
				"pointLights[" + std::to_string(i) + "].";

			const bool isActive = i < ACTIVE_POINT_LIGHTS;
			m_pShaderManager->setIntValue(
				(prefix + "bActive").c_str(), isActive);

			if (isActive)
			{
				const PointLightSettings& light = POINT_LIGHT_SETTINGS[i];

				m_pShaderManager->setVec3Value(
					(prefix + "position").c_str(), light.position);
				m_pShaderManager->setVec3Value(
					(prefix + "ambient").c_str(), light.ambient);
				m_pShaderManager->setVec3Value(
					(prefix + "diffuse").c_str(), light.diffuse);
				m_pShaderManager->setVec3Value(
					(prefix + "specular").c_str(), light.specular);
			}
		}

		m_pShaderManager->setIntValue("spotLight.bActive", false);
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	//set materials and lighting before drawing scene
	DefineObjectMaterials();
	SetupSceneLights();

	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	//loading meshes needed for surface and lamp
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();

	// check texture loads with fallback if needed
	if (!CreateGLTexture("textures/fabric.jpg", TEXTURE_FABRIC))
	{
		std::cout << "Fabric texture failed. Using fallback color."
			<< std::endl;
	}

	if (!CreateGLTexture("textures/metal.jpg", TEXTURE_METAL))
	{
		std::cout << "Metal texture failed. Using fallback color."
			<< std::endl;
	}

	if (!CreateGLTexture("textures/chainEnd.jpg", TEXTURE_CHAIN_END))
	{
		std::cout << "Chain end texture failed. Using fallback color."
			<< std::endl;
	}

	if (!CreateGLTexture("textures/wood.jpg", TEXTURE_WOOD))
	{
		std::cout << "Wood texture failed. Using fallback color."
			<< std::endl;
	}

	if (!CreateGLTexture("textures/novel.png", TEXTURE_NOVEL))
	{
		std::cout << "Novel texture failed. Using fallback color."
			<< std::endl;
	}

	BindGLTextures();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;


	/*** TABLETOP PLANE ***/

	//creating XYZ scale for mesh
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);

	//set XYZ rotation for mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	//set XYZ position for mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	//set transformations used to draw TABLETOP mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//set wood texture and material for tabletop
	SetShaderTexture(TEXTURE_WOOD);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial(TEXTURE_WOOD);

	//function to draw plane mesh
	m_basicMeshes->DrawPlaneMesh();

	//Function to draw objects with their seperate function
	DrawLamp();
	DrawBookSet();
	DrawGraphicNovel();
	DrawCupAndCoaster();
	DrawPS5();
}

/***********************************************************
 * DrawLamp()
 ***********************************************************/
void SceneManager::DrawLamp()
{
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** LAMP BASE ***/

	//creating XYZ scale for lamp base 
	scaleXYZ = glm::vec3(2.0f, 0.5f, 2.0f);

	//set rotation for lamp base to be upright
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	//set position for lamp base to be above tabletop so it does not clip 
	positionXYZ = glm::vec3(0.0f, 0.10f, 0.0f);

	//set transformations for lamp base
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	
	//apply metal texture
	SetShaderTexture(TEXTURE_METAL);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial(TEXTURE_METAL);

	//function to draw cylinder mesh
	m_basicMeshes->DrawCylinderMesh();

	/*** LAMP POLE ***/

	//creating XYZ scale for tall and thin cylinder that will be the lamp pole
	scaleXYZ = glm::vec3(0.15f, 6.0f, 0.15f);

	//set rotation for lamp pole to be upright
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	//set position for lamp pole to be on top of lamp base
	positionXYZ = glm::vec3(0.0f, 0.2f, 0.0f);

	//apply transformations for lamp pole
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//apply metal texture
	SetShaderTexture(TEXTURE_METAL);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial(TEXTURE_METAL);

	//function to draw cylinder mesh
	m_basicMeshes->DrawCylinderMesh();

	/*** LAMP SHADE ***/

	//creating XYZ scale for large cylinder lamp shade
	scaleXYZ = glm::vec3(2.8f, 4.5f, 2.8f);

	//set rotation for lamp shade to be upright
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	//set position for lamp shade to be on top of lamp Pole
	positionXYZ = glm::vec3(0.0f, 5.8f, 0.0f);

	//apply transformations for lamp shade
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//apply fabric texture
	SetShaderTexture(TEXTURE_FABRIC);
	SetTextureUVScale(2.0f, 1.0f);
	SetShaderMaterial(TEXTURE_FABRIC);

	//function to draw cylinder mesh
	m_basicMeshes->DrawCylinderMesh();


	/*** LAMP PULL CHAIN ***/

	//creating XYZ scale for thin/long pull chain
	scaleXYZ = glm::vec3(0.05f, 2.5f, 0.05f);

	//set rotation for lamp chain to be vertical
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	//set position for pull chain to hang below lamp shade
	positionXYZ = glm::vec3(-0.5f, 4.3f, 0.0f);

	//apply transformations for pull chain
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//apply metal texture
	SetShaderTexture(TEXTURE_METAL);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial(TEXTURE_METAL);

	//function to draw cylinder mesh
	m_basicMeshes->DrawCylinderMesh();

	/*** PULL CHAIN END ***/

	//creating XYZ scale for small sphere at end of pull chain
	scaleXYZ = glm::vec3(0.16f, 0.16f, 0.16f);

	//sphere rotation doesn't matter
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	//set position for sphere to connect at end of pull chain
	positionXYZ = glm::vec3(-0.5f, 4.2f, 0.0f);

	//apply transformations for chain end
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//apply chain end texture
	SetShaderTexture(TEXTURE_CHAIN_END);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial(TEXTURE_CHAIN_END);

	//function to draw sphere mesh
	m_basicMeshes->DrawSphereMesh();

}

/***********************************************************
 * DrawBookSet()
 ***********************************************************/
void SceneManager::DrawBookSet()
{
	constexpr int BOOK_COUNT = 3;
	constexpr float BOOK_SPACING = 0.85f;

	const glm::vec3 bookScale(0.80f, 4.5f, 2.0f);
	const glm::vec3 firstBookPosition(-5.5f, 2.25f, 2.5f);

	const glm::vec3 bookColors[BOOK_COUNT] =
	{
		glm::vec3(0.85f, 0.35f, 0.08f), // Orange book
		glm::vec3(1.0f, 0.35f, 0.65f), // Pink book
		glm::vec3(0.40f, 0.10f, 0.32f)  // Purple book
	};

	// Use subdued highlights 
	SetShaderMaterial(TEXTURE_FABRIC);

	// Reuse the box mesh and space the books along the X axis.
	for (int i = 0; i < BOOK_COUNT; i++)
	{
		glm::vec3 position = firstBookPosition;
		position.x += i * BOOK_SPACING;

		SetTransformations(
			bookScale,
			0.0f,
			0.0f,
			0.0f,
			position);

		// Kept front spine, back, and cover in their respective book's color.
		SetShaderColor(
			bookColors[i].r,
			bookColors[i].g,
			bookColors[i].b,
			1.0f);

		m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::front);
		m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::left);
		m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::right);

		// Light color to represent pages
		SetShaderColor(0.75f, 0.72f, 0.65f, 1.0f);
		m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::back);
		m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::top);
		m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::bottom);
	}
}
/***********************************************************
 * DrawGraphicNovel()
 ***********************************************************/
void SceneManager::DrawGraphicNovel()
{
	const glm::vec3 novelScale(3.0f, 5.5f, 0.65f);
	const glm::vec3 novelPosition(4.0f, 2.75f, 0.0f);

	SetTransformations(
		novelScale,
		0.0f,
		0.0f,
		0.0f,
		novelPosition);

	// Use subdued highlights 
	SetShaderMaterial(TEXTURE_FABRIC);

	// Draw the spine as black.
	SetShaderColor(0.03f, 0.03f, 0.03f, 1.0f);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::back);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::left);

	// White edges (the novel pages)
	SetShaderColor(0.75f, 0.72f, 0.65f, 1.0f);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::right);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::top);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::bottom);

	// Apply red texture to front cover.
	SetShaderTexture(TEXTURE_NOVEL);
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::front);
}
/***********************************************************
 * DrawCupAndCoaster()
 ***********************************************************/
void SceneManager::DrawCupAndCoaster()
{
	constexpr float CUP_X = 4.5f;
	constexpr float CUP_Z = 3.5f;
	constexpr float COASTER_HEIGHT = 0.20f;
	constexpr float CUP_HEIGHT = 3.8f;
	constexpr float CUP_RADIUS = 1.1f;

	// The cylinder starts at Y = 0, so the coaster rests on the table.
	SetTransformations(
		glm::vec3(1.35f, COASTER_HEIGHT, 1.35f),
		0.0f,
		0.0f,
		0.0f,
		glm::vec3(CUP_X, 0.0f, CUP_Z));

	SetShaderTexture(TEXTURE_WOOD);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial(TEXTURE_WOOD);
	m_basicMeshes->DrawCylinderMesh();

	// Flip the tapered mesh so its wider end becomes the cup opening.
	// After rotation, raise it by its height to rest on the coaster.
	SetTransformations(
		glm::vec3(CUP_RADIUS, CUP_HEIGHT, CUP_RADIUS),
		180.0f,
		0.0f,
		0.0f,
		glm::vec3(CUP_X, COASTER_HEIGHT + CUP_HEIGHT + 0.02f, CUP_Z));

	// Use plastic material with a light gray surface.
	SetShaderMaterial(MATERIAL_PLASTIC);
	SetShaderColor(0.65f, 0.68f, 0.70f, 1.0f);

	// The original top is now the cup's bottom
	m_basicMeshes->DrawTaperedCylinderMesh(true, false, true);
}
/***********************************************************
 * DrawPS5()
 ***********************************************************/
void SceneManager::DrawPS5()
{
	const glm::vec3 consolePosition(8.0f, 0.0f, -0.5f);

	constexpr float BODY_HEIGHT = 7.0f;
	constexpr float PANEL_HEIGHT = 7.4f;
	constexpr float PANEL_OFFSET = 0.85f;

	// Use subdued highlights for the console's plastic surfaces.
	SetShaderMaterial(TEXTURE_FABRIC);

	// Black center body.
	SetTransformations(
		glm::vec3(1.5f, BODY_HEIGHT, 2.5f),
		0.0f,
		0.0f,
		0.0f,
		consolePosition + glm::vec3(0.0f, BODY_HEIGHT / 2.0f, 0.0f));

	SetShaderColor(0.025f, 0.025f, 0.03f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// Reuse the box mesh for the left and right white panels.
	for (int side = -1; side <= 1; side += 2)
	{
		SetTransformations(
			glm::vec3(0.20f, PANEL_HEIGHT, 2.8f),
			0.0f,
			0.0f,
			0.0f,
			consolePosition + glm::vec3(
				side * PANEL_OFFSET,
				PANEL_HEIGHT / 2.0f,
				0.0f));

		SetShaderColor(0.80f, 0.80f, 0.82f, 1.0f);
		m_basicMeshes->DrawBoxMesh();
	}
}